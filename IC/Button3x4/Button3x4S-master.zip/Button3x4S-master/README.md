[Button3x4S](https://github.com/KitSprout/Button3x4S)
========
* Author  : [Hom](https://about.me/Hom)
* Version : v1.0
* Update  : 2014/08/16

Description
========
Button 模組，接上上拉電阻，On - 0, Off - 1。

License
========
* 硬體(Hardware)採用 [CC BY-SA 4.0](http://creativecommons.org/licenses/by-sa/4.0/deed.zh_TW) 方式授權 
  
　　<a rel="license" href="http://creativecommons.org/licenses/by-sa/4.0/deed.zh_TW"><img alt="創用 CC 授權條款" style="border-width:0" src="http://i.creativecommons.org/l/by-sa/3.0/tw/80x15.png" /></a>  
　　<span xmlns:dct="http://purl.org/dc/terms/" property="dct:title"> Button3x4S </span>由<a xmlns:cc="http://creativecommons.org/ns#" href="https://github.com/KitSprout" property="cc:attributionName" rel="cc:attributionURL"> KitSprout </a>製作，以<a rel="license" href="http://creativecommons.org/licenses/by-sa/4.0/deed.zh_TW"> 創用CC 姓名標示-相同方式分享 4.0 國際 授權條款 </a>釋出。  

Hardware
========
* 設計軟體 [Altium Designer 14](http://www.altium.com/en/products/altium-designer) ( PcbLib use AD [PcbLib v1.0](https://github.com/KitSprout/AltiumDesigner_PcbLibrary/releases/tag/v1.0) ) 
* PCB 尺寸 :  
Button3x4S-1 -> 400x300 mil  
Button3x4S-2 -> 400x400 mil  
Button3x4S-3 -> 400x500 mil  
Button3x4S-4 -> 400x600 mil  

Related Documents
========
* [Google Drive](http://goo.gl/YLKalW)

View
========
<img src="https://lh4.googleusercontent.com/-gZdfp9kSO98/U-7G7ftculI/AAAAAAAAKac/C3c4QBqhoEI/s1600/DSC_2412.jpg" />

Schematic
========
<img src="https://lh6.googleusercontent.com/-PKyjcxhZPcw/U-7G80Y0OAI/AAAAAAAAKbA/zYkzjwRjBdE/s1600/Sch_Button3x4S-4.png" />
